package com.cg.Spring.RestFul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestFulApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestFulApplication.class, args);
	}

}
