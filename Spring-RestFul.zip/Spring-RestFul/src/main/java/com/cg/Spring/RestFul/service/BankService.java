
package com.cg.Spring.RestFul.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.cg.Spring.RestFul.dao.BankEntityDao;
import com.cg.Spring.RestFul.dao.TransactionEntityDao;
import com.cg.Spring.RestFul.entity.BankEntity;
import com.cg.Spring.RestFul.entity.TransactionEntity;

@Service
public class BankService
{
	@Autowired
	BankEntityDao dao;
	
	@Autowired
	TransactionEntityDao transactionDao;
	
	public List<BankEntity> CreateAccount(BankEntity bankEntity)
	{
		dao.save(bankEntity);
		return dao.findAll();
	}

	public float ShowBalance(long accno)
	{
		return dao.findById(accno).get().getBalance();
	}

	public Optional<BankEntity> Deposit(long accn, double amount)
	{
		BankEntity bank = dao.findById(accn).get();
		TransactionEntity transaction = new TransactionEntity();
		float initialBalance = bank.getBalance();
		float finalBalance = (float) (initialBalance + amount);
		bank.setBalance(finalBalance);
		transaction.setTransactionType("Deposit");
		transaction.setAccountNumber(accn);
		transaction.setAmount(amount);
		transactionDao.save(transaction);
		dao.save(bank);
		return dao.findById(accn);
	}

	public Optional<BankEntity> WithDraw(long accno, double amount) 
	{
		BankEntity bank = dao.findById(accno).get();
		TransactionEntity transaction = new TransactionEntity();
		float initialBalance = bank.getBalance();
		float finalBalance = (float) (initialBalance - amount);
		bank.setBalance(finalBalance);
		transaction.setAccountNumber(accno);
		transaction.setAmount(amount);
		transaction.setTransactionType("Withdraw");
		transactionDao.save(transaction);
		dao.save(bank);
		return dao.findById(accno);
	}

	public List<BankEntity> TransferFund(long sourceaccno, long destinationaccno, double amount) 
	{
		BankEntity sourceCust = dao.findById(sourceaccno).get();
		TransactionEntity transaction=new TransactionEntity();
		TransactionEntity destitransaction=new TransactionEntity();
		BankEntity destiCust = dao.findById(destinationaccno).get();
		float sourceInitialbal = sourceCust.getBalance();
		float destiInitialbal = destiCust.getBalance();
		float sourceFinalBal = (float) (sourceInitialbal - amount);
		float destiFinalBal = (float) (destiInitialbal + amount);
		sourceCust.setBalance(sourceFinalBal);
		destiCust.setBalance(destiFinalBal);
		transaction.setAccountNumber(sourceaccno);
		transaction.setAmount(amount);
		transaction.setTransactionType("Transfer");
		transactionDao.save(transaction);
		destitransaction.setAccountNumber(destinationaccno);
		destitransaction.setTransactionType("transfer");
		destitransaction.setAmount(amount);
		transactionDao.save(destitransaction);
		return dao.findAll();
	}

	public List<TransactionEntity> PrintTransaction(long accno)
	{
		return transactionDao.printTransaction(accno);
	}	
	
}
