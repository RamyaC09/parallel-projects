package com.cg.Spring.RestFul.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Spring.RestFul.entity.BankEntity;
import com.cg.Spring.RestFul.entity.TransactionEntity;
import com.cg.Spring.RestFul.service.BankService;

@RestController
public class BankController
{
	@Autowired
	BankService bankService;
	
	@PostMapping("/create")
	public List<BankEntity> CreateAccount(@RequestBody BankEntity bankEntity)
	{
		return bankService.CreateAccount(bankEntity);
	}
	
	@GetMapping("/showbalance/{accno}")
	public float ShowBalance(@PathVariable long accno) 
	{
		return bankService.ShowBalance(accno);
	}
	
	@PutMapping("/depositamount/{accn}/{amount}")
	public Optional<BankEntity> Deposit(@PathVariable long accn,@PathVariable double amount) {
		return bankService.Deposit(accn,amount);
	}
	
	@PutMapping("/withdrawamount/{accno}/{amount}")
	public Optional<BankEntity> WithDraw(@PathVariable long accno,@PathVariable double amount) {
		return bankService.WithDraw(accno,amount);
	}
	
	@PutMapping("/transferfund/{sourceaccno}/{destinationaccno}/{amount}")
	public List<BankEntity> TransferFund(@PathVariable long sourceaccno,@PathVariable long destinationaccno,@PathVariable double amount){
		return bankService.TransferFund(sourceaccno,destinationaccno,amount);
	}
	
	@GetMapping("/printstatement/{accno}")
	public List<TransactionEntity> PrintTransaction(@PathVariable long accno){
		return bankService.PrintTransaction(accno);
	}
	
}
