package com.cg.Spring.RestFul.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.Spring.RestFul.entity.BankEntity;

@Repository
public interface BankEntityDao  extends JpaRepository<BankEntity,Long>
{

}
