package com.cg.Spring.RestFul.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.Spring.RestFul.entity.TransactionEntity;


public interface TransactionEntityDao extends JpaRepository <TransactionEntity,Long> 
{
	@Query("from TransactionEntity where AccountNumber=:accn")
	List<TransactionEntity> findById(@Param("accn") long acc);

	List<TransactionEntity> printTransaction(long accno);
}
