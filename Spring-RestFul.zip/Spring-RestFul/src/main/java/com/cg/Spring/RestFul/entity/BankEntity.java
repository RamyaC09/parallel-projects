package com.cg.Spring.RestFul.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "BankEntity")
public class BankEntity 
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AccId")
    @SequenceGenerator(name="AccId", initialValue=500, allocationSize=1, sequenceName = "customerAccNo")
    @Column(name="CustomerAccNo", updatable=false, nullable=false)
	private Long accNo;
	private String name;
	private long phoneNo;
	private float balance;
	private long aadharNo;
			
	//Generating parameterized Constructor
		 
	private BankEntity(Long accNo, String name, long phoneNo, float balance, long aadharNo) {
		super();
		this.accNo = accNo;
		this.name = name;
		this.phoneNo = phoneNo;
		this.balance = balance;
		this.aadharNo = aadharNo;
	}
	
	private BankEntity()
	{
		
	}
	
	//Generating getters & setters

	public Long getAccNo() {
		return accNo;
	}

	public void setAccNo(Long accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public long getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}

	//Generating toString Method
	
	@Override
	public String toString() {
		return "BankEntity [accNo=" + accNo + ", name=" + name + ", phoneNo=" + phoneNo + ", balance=" + balance
				+ ", aadharNo=" + aadharNo + "]";
	}	
			
		
}


