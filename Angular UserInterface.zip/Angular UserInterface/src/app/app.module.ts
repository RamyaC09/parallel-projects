import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './home-page/home-page.component';
import { CreateNewUserComponent } from './create-new-user/create-new-user.component';
import { AddBalanceComponent } from './add-balance/add-balance.component';
import { TransferMoneyComponent } from './transfer-money/transfer-money.component';
import { SearchUserComponent } from './search-user/search-user.component';
import { ShowAllUsersComponent } from './show-all-users/show-all-users.component';
import { FilterPipe } from './filter.pipe';
import { TransactionsComponent } from './transactions/transactions.component';
import { WithdrawComponent } from './withdraw/withdraw.component';

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    CreateNewUserComponent,
    AddBalanceComponent,
    TransferMoneyComponent,
    SearchUserComponent,
    ShowAllUsersComponent,
    FilterPipe,
    TransactionsComponent,
    WithdrawComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
