import { Component, OnInit } from '@angular/core';
import data from '../../Data Storage/MyData.json'
@Component({
  selector: 'app-show-all-users',
  templateUrl: './show-all-users.component.html',
  styleUrls: ['./show-all-users.component.css']
})
export class ShowAllUsersComponent implements OnInit {
  array=data
  constructor() { }

  ngOnInit() {
  }

}
