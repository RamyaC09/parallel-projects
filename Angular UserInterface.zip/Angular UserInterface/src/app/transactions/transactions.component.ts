import { Component, OnInit } from '@angular/core';
import transactions from '../../Data Storage/Transactions.json'
@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  array=transactions
  array1=[];
  flag=false
  constructor() { }

  ngOnInit() {
  }

  setFlag(number){
    this.array1.splice(0,20)
    this.array.forEach(element => {
      if(element.accNum==number)
      {
        this.array1.push(element)
      }
    });
    this.flag=true
  }
}
