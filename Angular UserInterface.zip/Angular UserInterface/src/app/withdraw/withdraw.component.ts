import { Component, OnInit } from '@angular/core';
import data from '../../Data Storage/MyData.json'
import transactions from '../../Data Storage/Transactions.json'
import {formatDate } from '@angular/common';
@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  array=data
  transactionArray=transactions
  flag=false
  successflag=false
  constructor() { }

  ngOnInit() {
  }
 
  find(number){
    this.array.forEach(element => {
      if(element.accNum==number)
      {
        this.flag=true
      }
    });
    
  }
  update(number, amount){
    this.array.forEach(element => {
      if(element.accNum==number)
      {
        if(element.balance>amount)
        {
          let temp=element.balance
        element.balance=temp-amount
  let now = new Date();
  let today = formatDate(now, 'dd-MM-yyyy hh:mm:ss a', 'en-US', '+0530');
  this.transactionArray.push({
    accNum: number,
    date: today,
    type: "Withdraw",
    Amount: amount
  })
        }
      }
    });
    this.successflag=true
  }
}
