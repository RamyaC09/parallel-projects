import { Component, OnInit } from '@angular/core';
import data from '../../Data Storage/MyData.json'
import transactions from '../../Data Storage/Transactions.json'
import {formatDate } from '@angular/common';
@Component({
  selector: 'app-transfer-money',
  templateUrl: './transfer-money.component.html',
  styleUrls: ['./transfer-money.component.css']
})
export class TransferMoneyComponent implements OnInit {
  array = data
  successflag=false
  flag = false
  faccount1 = false
  faccount2 = false
  check = false
  array1 = [];
  temp1: any
  temp2: any
  transactionArray=transactions
  constructor() { }

  ngOnInit() {
  }

  find(number1, number2) {
    let length = this.array1.length
    this.array1.splice(0, length)
    this.array.forEach(element => {
      if (element.accNum == number1 || element.accNum == number2) {
        this.array1.push(element)
      }
    });
    this.flag = true
  }
  transfer(number1, number2, amount) {
    this.faccount1 = false
    this.faccount2 = false
    this.array.forEach(element => {
      if (element.accNum == number1) {
        this.temp1 = element.balance
        this.faccount1 = true;
      }
      else if (element.accNum == number2) {
        this.temp2 = element.balance
        this.faccount2 = true
      }
    }
    );
    if (this.faccount1 && this.faccount2) {
      if (this.temp1 >= amount) {
        this.temp1 = this.temp1 - amount
        this.temp2 = this.temp2 + amount
        this.successflag=true
      }
      else{
        this.successflag=false
      }
      this.array.forEach(element => {
        if (element.accNum == number1) {
          element.balance = this.temp1;
          let now = new Date();
        let today = formatDate(now, 'dd-MM-yyyy hh:mm:ss a', 'en-US', '+0530'); 
        this.transactionArray.push({
          accNum: element.accNum,
          date: today,
          type: "Transfer-sent",
          Amount: amount
        })
        }
        else if (element.accNum == number2) {
          element.balance = this.temp2;
          let now = new Date();
        let today = formatDate(now, 'dd-MM-yyyy hh:mm:ss a', 'en-US', '+0530'); 
        this.transactionArray.push({
          accNum: element.accNum,
          date: today,
          type: "Transfer-recieved",
          Amount: amount
        })
        }
      });
    }
  }
}
