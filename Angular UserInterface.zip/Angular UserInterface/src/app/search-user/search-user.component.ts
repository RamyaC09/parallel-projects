import { Component, OnInit } from '@angular/core';
import data from '../../Data Storage/MyData.json'

@Component({
  selector: 'app-search-user',
  templateUrl: './search-user.component.html',
  styleUrls: ['./search-user.component.css']
})
export class SearchUserComponent implements OnInit {
  array=data
  flag=false
    constructor() { }
  
    ngOnInit() {
    }
  
    setFlag()
    {
      this.flag=true
    }
}
