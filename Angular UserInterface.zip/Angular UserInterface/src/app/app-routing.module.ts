import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { CreateNewUserComponent } from './create-new-user/create-new-user.component';
import { AddBalanceComponent } from './add-balance/add-balance.component';
import { TransferMoneyComponent } from './transfer-money/transfer-money.component';
import { SearchUserComponent } from './search-user/search-user.component';
import { ShowAllUsersComponent } from './show-all-users/show-all-users.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { WithdrawComponent } from './withdraw/withdraw.component';

const routes: Routes = [
  {
    path: '',
    component: HomePageComponent
  },
  {
    path: 'create-user',
    component: CreateNewUserComponent
  },
  {
    path: 'search-user',
    component: SearchUserComponent
  },
  {
    path: 'add-money',
    component: AddBalanceComponent
  },
  {
    path: 'transfer-money',
    component: TransferMoneyComponent
  },
  {
    path: 'show-all',
    component: ShowAllUsersComponent
  },
  {
    path: 'app-transactions',
    component: TransactionsComponent
  },
  {
    path: 'app-withdraw',
    component: WithdrawComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
