import { Component, OnInit } from '@angular/core';
import data from '../../Data Storage/MyData.json';
import transactions from '../../Data Storage/Transactions.json'
import {formatDate } from '@angular/common';
@Component({
  selector: 'app-create-new-user',
  templateUrl: './create-new-user.component.html',
  styleUrls: ['./create-new-user.component.css']
})
export class CreateNewUserComponent implements OnInit {
  array = data
  transactionArray=transactions
  accNum: number;
  successflag = false
  constructor() { }

  ngOnInit() {
  }

  add(form) {
    this.accNum = Math.floor(Math.random() * 1000) + 1
    this.array.push({
      accNum: this.accNum,
      name: form.name,
      phone: form.phone,
      email: form.email,
      balance: 0
    })
    let now = new Date();
    let today = formatDate(now, 'dd-MM-yyyy hh:mm:ss a', 'en-US', '+0530'); 
    this.transactionArray.push({
      accNum: this.accNum,
      date: today,
      type: "creation",
      Amount: 0
    })
    this.successflag = true;
  }
}
